<?php

$conn = mysqli_connect('localhost','root', '', 'todolist') or die ('Gagal terhubung ke database');